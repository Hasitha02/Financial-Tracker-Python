import json
import tkinter as tk
from tkinter import messagebox, ttk, simpledialog, scrolledtext
from datetime import datetime


class FinanceTrackerApp:
    def __init__(self, root):
        # Initialize the FinanceTrackerApp with the root window
        self.root = root
        self.root.title("Finance Tracker")
        self.entries = []  # List to store financial entries
        self.create_widgets()  # Create GUI widgets

    def create_widgets(self):
        # Labels for input fields
        tk.Label(self.root, text="Amount (Rs.):").grid(row=1, column=0, padx=5, pady=5)
        tk.Label(self.root, text="Category:").grid(row=2, column=0, padx=5, pady=5)
        tk.Label(self.root, text="Date (YYYY-MM-DD):").grid(row=3, column=0, padx=5, pady=5)

        # Radio buttons for choosing income or expense
        self.type_var = tk.StringVar()
        self.type_var.set("income")  # Default to income
        self.income_radio = tk.Radiobutton(self.root, text="Income", variable=self.type_var, value="income")
        self.income_radio.grid(row=0, column=1, padx=5, pady=5)
        self.expense_radio = tk.Radiobutton(self.root, text="Expense", variable=self.type_var, value="expense")
        self.expense_radio.grid(row=0, column=2, padx=5, pady=5)

        # Entry widgets for user input
        self.amount_entry = tk.Entry(self.root, borderwidth=3)
        self.amount_entry.grid(row=1, column=1, columnspan=2, padx=5, pady=5)

        self.category_entry = tk.Entry(self.root, borderwidth=3)
        self.category_entry.grid(row=2, column=1, columnspan=2, padx=5, pady=5)

        self.date_entry = tk.Entry(self.root, borderwidth=3)
        self.date_entry.grid(row=3, column=1, columnspan=2, padx=5, pady=5)

        # Text box to display all entries
        self.entries_textbox = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, width=50, height=18)
        self.entries_textbox.grid(row=4, column=1, columnspan=4, pady=10)

        # Labels and button for totals
        tk.Label(self.root, text="Totals:").grid(row=5, column=0, padx=5, pady=5)
        self.totals_label = tk.Label(self.root, text="")
        self.totals_label.grid(row=5, column=1, columnspan=3, pady=5)

        # Buttons for inputs
        ttk.Button(self.root, text="Record Entry", command=self.record_entry, width=20).grid(row=6, column=0, columnspan=2, pady=10, padx=5)
        ttk.Button(self.root, text="View All Entries", command=self.view_all_entries, width=20).grid(row=6, column=2, columnspan=2, pady=10, padx=5)
        ttk.Button(self.root, text="Calculate Totals", command=self.calculate_totals, width=20).grid(row=7, column=0, columnspan=2, pady=10, padx=5)
        ttk.Button(self.root, text="Monthly Summary", command=self.monthly_summary, width=20).grid(row=7, column=2, columnspan=2, pady=10, padx=5)
        ttk.Button(self.root, text="Save to File", command=self.save_to_file, width=20).grid(row=8, column=0, columnspan=2, pady=10, padx=5)
        ttk.Button(self.root, text="Load from File", command=self.load_from_file, width=20).grid(row=8, column=2, columnspan=2, pady=10, padx=5)
        ttk.Button(self.root, text="Display Loaded Entries", command=self.display_loaded_entries, width=20).grid(row=9, column=0, columnspan=4, pady=10, padx=5)

    def record_entry(self):
        # Function to record a financial entry
        entry_type = self.type_var.get()
        amount_str = self.amount_entry.get()
        category = self.category_entry.get()
        date_str = self.date_entry.get()

        valid_entry_types = ["income", "expense"]

        if entry_type not in valid_entry_types:
            messagebox.showerror("Error", "Invalid entry type. Please select either 'Income' or 'Expense'.")
            return

        # Validate date format
        try:
            date = datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            messagebox.showerror("Error", "Invalid date format. Please enter a valid date (YYYY-MM-DD).")
            return

        # Validate amount
        try:
            amount = float(amount_str)
        except ValueError:
            messagebox.showerror("Error", "Invalid amount. Please enter a valid number.")
            return

        # Validate category is a non-empty string
        if not isinstance(category, str) or not category.strip() or not category.isalpha():
            messagebox.showerror("Error", "Invalid input. Please enter a valid category (only letters).")
            return

        entry = {"type": entry_type, "amount": amount, "category": category, "date": date}
        self.entries.append(entry)
        messagebox.showinfo("Success", "Entry recorded successfully!")

    def view_all_entries(self):
        # Function to display all recorded financial entries
        if not self.entries:
            messagebox.showinfo("Info", "No entries to display.")
            return

        # Clear existing text in the text box
        self.entries_textbox.delete(1.0, tk.END)

        # Append entries to the text box
        for entry in self.entries:
            entry_str = f"Type: {entry['type']}, Amount: Rs.{entry['amount']}, Category: {entry['category']}, Date: {entry['date']}\n"
            self.entries_textbox.insert(tk.END, entry_str)

        # Show the text box as a separate window
        self.show_entries_textbox()

    def show_entries_textbox(self):
        # Function to display the text box with all entries
        entries_window = tk.Toplevel(self.root)
        entries_window.title("All Entries")
        entries_window.resizable(False, False)

        # Copy the content from the main window's text box to the new window's text box
        entries_textbox_copy = scrolledtext.ScrolledText(entries_window, wrap=tk.WORD, width=50, height=20)
        entries_textbox_copy.grid(row=0, column=0, pady=10)

        entries_textbox_copy.insert(tk.END, self.entries_textbox.get(1.0, tk.END))

    def calculate_totals(self):
        # Function to calculate and display total income, total expenses, and net income
        total_income = sum(entry["amount"] for entry in self.entries if entry["type"] == "income")
        total_expenses = sum(entry["amount"] for entry in self.entries if entry["type"] == "expense")
        net_income = total_income - total_expenses

        totals_str = f"Total Income: Rs.{total_income}\nTotal Expenses: Rs.{total_expenses}\nNet Income: Rs.{net_income}"

        # Check if net income is negative and display an error message
        if net_income < 0:
            messagebox.showerror("Error",
                                 "Net Income is negative! Take necessary actions to improve your financial situation.")
        else:
            # Update the totals label
            self.totals_label.config(text=totals_str)

    def monthly_summary(self):
        # Function to generate and display a summary of financial entries for the specified month and year

        # Prompt the user to enter the month
        month_str = simpledialog.askstring("Enter Month", "Enter Month (1-12):")
        if month_str is None:
            # User clicked Cancel
            return

        # Prompt the user to enter the year
        year_str = simpledialog.askstring("Enter Year", "Enter Year:")
        if year_str is None:
            # User clicked Cancel
            return

        if not month_str or not year_str:
            messagebox.showerror("Error", "Please enter both Month and Year to see the monthly summary.")
            return

        try:
            month_input = int(month_str)
            year_input = int(year_str)
            if not 1 <= month_input <= 12:
                raise ValueError("Month should be between 1 and 12.")
        except ValueError:
            messagebox.showerror("Error", "Invalid month or year. Please enter valid values.")
            return

        # Filter entries for the specified month and year
        monthly_entries = [entry for entry in self.entries if
                           entry["date"].month == month_input and entry["date"].year == year_input]

        total_income = sum(entry["amount"] for entry in monthly_entries if entry["type"] == "income")
        total_expenses = sum(entry["amount"] for entry in monthly_entries if entry["type"] == "expense")

        summary_str = f"Summary for {datetime(year_input, month_input, 1).strftime('%B %Y')}:\nTotal Income: Rs.{total_income}\nTotal Expenses: Rs.{total_expenses}"
        messagebox.showinfo("Monthly Summary", summary_str)

    def display_loaded_entries(self):
        # Function to display loaded entries after loading from a file
        if not self.entries:
            messagebox.showinfo("Info", "No entries to display.")
            return

        entry_str = "\n".join([
            f"Type: {entry['type']}, Amount: Rs.{entry['amount']}, Category: {entry['category']}, Date: {entry['date']}"
            for entry in self.entries
        ])

        # Show the text box with loaded entries
        self.show_entries_textbox_with_text(entry_str)

    def show_entries_textbox_with_text(self, text):
        # Function to display a text box with loaded entries
        loaded_entries_window = tk.Toplevel(self.root)
        loaded_entries_window.title("Loaded Entries")
        loaded_entries_window.resizable(False, False)

        # Text box to display loaded entries
        loaded_entries_textbox = scrolledtext.ScrolledText(loaded_entries_window, wrap=tk.WORD, width=50, height=20)
        loaded_entries_textbox.grid(row=0, column=0, pady=10)

        loaded_entries_textbox.insert(tk.END, text)


    def save_to_file(self):
        # Function to save financial entries to a file
        if not self.entries:
            messagebox.showwarning("Warning", "No entries to save.")
            return
        try:
            file_path = "financial_data.json"  # Specify complete file path
            with open(file_path, "w") as file:
                json.dump(self.entries, file, default=str)
            messagebox.showinfo("Success", "Data saved to file.")
        except Exception as e:
            messagebox.showerror("Error", f"Error saving data to file: {e}")

    def load_from_file(self):
        # Function to load financial entries from a file
        try:
            file_path = "financial_data.json"  # Specify complete file path
            with open(file_path, "r") as file:
                loaded_entries = json.load(file)

            # Convert date strings to datetime.date objects
            for entry in loaded_entries:
                entry["date"] = datetime.strptime(entry["date"], "%Y-%m-%d").date()

            self.entries = loaded_entries
            messagebox.showinfo("Success", "Data loaded from file.")

            # After loading entries, display loaded data
            self.display_loaded_entries()

        except FileNotFoundError:
            messagebox.showwarning("Warning", "No data file found.")
        except json.JSONDecodeError as e:
            messagebox.showerror("Error", f"Error decoding JSON: {e}")
        except Exception as e:
            messagebox.showerror("Error", f"Error loading data from file: {e}")


if __name__ == "__main__":
    # Runs the application
    root = tk.Tk()
    app = FinanceTrackerApp(root)
    root.geometry("900x800")  # Increased height to accommodate the label and button
    root.mainloop()
